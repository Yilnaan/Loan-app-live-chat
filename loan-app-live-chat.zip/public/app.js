// public/app.js
(() => {
  const loanForm = document.getElementById('loanForm');
  const formResult = document.getElementById('formResult');
  const appsList = document.getElementById('appsList');

  loanForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    formResult.textContent = 'Submitting...';
    const data = Object.fromEntries(new FormData(loanForm).entries());
    try {
      const res = await fetch('/api/apply', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          fullName: data.fullName,
          email: data.email,
          amount: Number(data.amount),
          termMonths: Number(data.termMonths),
          purpose: data.purpose
        })
      });
      const json = await res.json();
      if (!res.ok) {
        formResult.textContent = 'Error: ' + (json.errors||[]).join(', ');
        formResult.classList.add('error');
      } else {
        formResult.textContent = 'Application submitted! ID: ' + json.application.id;
        formResult.classList.remove('error');
        loanForm.reset();
        loadApps();
      }
    } catch (err) {
      formResult.textContent = 'Network error';
      formResult.classList.add('error');
    }
  });

  async function loadApps() {
    try {
      const res = await fetch('/api/apps');
      const json = await res.json();
      if (json.ok) {
        appsList.textContent = JSON.stringify(json.applications, null, 2);
      }
    } catch (e) {
      appsList.textContent = 'Unable to load';
    }
  }

  loadApps();

  // Live chat via Socket.IO
  const socket = io();
  const chatWindow = document.getElementById('chatWindow');
  const chatForm = document.getElementById('chatForm');
  const chatName = document.getElementById('chatName');
  const chatMessage = document.getElementById('chatMessage');
  const roomId = 'public'; // demo: single public room; in real app use session or application id

  function appendMessage(msg, kind='msg') {
    const el = document.createElement('div');
    el.className = 'chatEntry ' + kind;
    const time = new Date(msg.ts).toLocaleTimeString();
    el.innerHTML = '<strong>' + (msg.name || 'System') + '</strong> <span class="time">['+time+']</span><div class="text">'+(msg.text || '')+'</div>';
    chatWindow.appendChild(el);
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

  socket.on('connect', () => {
    socket.emit('join', roomId);
  });
  socket.on('system', (m) => appendMessage({name:'System', text: m.message, ts: new Date().toISOString()}, 'sys'));
  socket.on('message', (m) => appendMessage(m));

  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = chatName.value.trim() || 'Visitor';
    const text = chatMessage.value.trim();
    if (!text) return;
    const amount = document.querySelector('input[name="amount"]')?.value || '';
    const payload = { room: roomId, name, text, amount };
    socket.emit('message', payload);
    chatMessage.value = '';
  });

})();
