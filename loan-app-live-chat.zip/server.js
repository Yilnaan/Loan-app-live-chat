// server.js
// Minimal Express + Socket.IO server to support:
// - POST /api/apply -> receive loan applications (simple validation, stored in-memory)
// - GET /api/apps -> list applications
// - static files served from /public
// - Socket.IO live chat (rooms by session id). Includes a simple bot reply.
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory store (for demo only)
const applications = [];

function validateApplication(data) {
  const errors = [];
  if (!data.fullName || data.fullName.trim().length < 3) errors.push('fullName');
  if (!data.email || !/^\S+@\S+\.\S+$/.test(data.email)) errors.push('email');
  if (!data.amount || isNaN(Number(data.amount)) || Number(data.amount) <= 0) errors.push('amount');
  if (!data.termMonths || !Number.isInteger(data.termMonths) || data.termMonths <= 0) errors.push('termMonths');
  return errors;
}

app.post('/api/apply', (req, res) => {
  const data = req.body || {};
  const errors = validateApplication(data);
  if (errors.length) {
    return res.status(400).json({ ok: false, errors });
  }
  const id = applications.length + 1;
  const record = {
    id,
    fullName: data.fullName,
    email: data.email,
    amount: Number(data.amount),
    termMonths: Number(data.termMonths),
    purpose: data.purpose || '',
    createdAt: new Date().toISOString()
  };
  applications.push(record);
  // In a real app you'd send email, create DB record, run credit checks, etc.
  return res.json({ ok: true, application: record });
});

app.get('/api/apps', (req, res) => {
  res.json({ ok: true, applications });
});

// Socket.IO live chat
io.on('connection', (socket) => {
  console.log('user connected', socket.id);
  // Join a room if provided (session id)
  socket.on('join', (room) => {
    socket.join(room);
    socket.room = room;
    socket.emit('system', { message: 'Connected to live chat.' });
  });

  socket.on('message', (payload) => {
    // payload: { room, name, text }
    const room = payload.room || socket.room || 'public';
    const msg = {
      id: Date.now(),
      name: payload.name || 'Visitor',
      text: payload.text,
      ts: new Date().toISOString()
    };
    // Broadcast to room
    io.to(room).emit('message', msg);

    // Simple bot reply (simulate agent or bot)
    setTimeout(() => {
      const bot = {
        id: Date.now()+1,
        name: 'LoanBot',
        text: `Hi ${msg.name.split(' ')[0] || ''}! Thanks for the message. For loan of $${payload.amount||'N/A'} we typically respond within 24 hours. Ask me anything or type "agent" to request a human.`,
        ts: new Date().toISOString()
      };
      io.to(room).emit('message', bot);
    }, 700);
  });

  socket.on('disconnect', () => {
    console.log('user disconnected', socket.id);
  });
});

// Start
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('Server running on port', PORT);
});

